import { Popover as HeadlessuiPopover } from '@headlessui/react'
import { Placement } from '@popperjs/core'
import { classNames } from 'app/functions'
import useInterval from 'app/hooks/useInterval'
import React, { Fragment, useCallback, useState } from 'react'
// @ts-ignore TYPE NEEDS FIXING
import ReactDOM from 'react-dom'
import { usePopper } from 'react-popper'
// @ts-ignore: Unreachable code error
// eslint-disable-next-line simple-import-sort/imports
import { Arwes, ThemeProvider, Button, Heading, Paragraph, Frame, createTheme, SoundsProvider, createSounds, withSounds } from 'arwes';
export interface PopoverProps {
  content: React.ReactNode
  children: React.ReactNode
  placement?: Placement
  show?: boolean
  modifiers?: any[]
  fullWidth?: boolean
}

export default function Popover({ content, children, placement = 'auto', show, modifiers }: PopoverProps) {
  const [referenceElement, setReferenceElement] = useState<HTMLDivElement | null>(null)
  const [popperElement, setPopperElement] = useState<HTMLDivElement | null>(null)
  const [arrowElement, setArrowElement] = useState<HTMLDivElement | null>(null)
  const { styles, update, attributes } = usePopper(referenceElement, popperElement, {
    placement,
    strategy: 'fixed',
    modifiers: modifiers || [
      { name: 'offset', options: { offset: [0, 8] } },
      { name: 'arrow', options: { element: arrowElement } },
    ],
  })

  const updateCallback = useCallback(() => {
    update && update()
  }, [update])

  useInterval(updateCallback, show ? 100 : null)

  return (
    <HeadlessuiPopover as={Fragment}>
      {({ open }) => (
        <>
          {React.Children.map(children, (child) => {
            return (
              <HeadlessuiPopover.Button as={Fragment} {...{ ref: setReferenceElement as any }}>
                {child}
              </HeadlessuiPopover.Button>
            )
          })}
          {(show ?? open) &&
            ReactDOM.createPortal(
              <HeadlessuiPopover.Panel
                static
                
                ref={setPopperElement as any}
                style={styles.popper}
                {...attributes.popper}
              >
                <Frame animate={true}
                  level={3}
                  corners={4}
                  layer='primary'>
                  {content}
                </Frame>
                <div
                  className={classNames('w-2 h-2 z-50')}
                  ref={setArrowElement as any}
                  style={styles.arrow}
                  {...attributes.arrow}
                />
              </HeadlessuiPopover.Panel>,
              document.querySelector('#popover-portal')

            )}
        </>
      )}
    </HeadlessuiPopover>
  )
}
